"""
visualizations.py
------------------
Generates and saves all EDA charts to the charts/ folder.
Charts produced:
  1. Distribution histograms (per feature, per species)
  2. Box plots (all features vs species)
  3. Scatter plot matrix (pair plot)
  4. Correlation heatmap
  5. Violin plots
  6. Scatter: petal length vs petal width (most discriminative)
"""

import os
import warnings
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
import pandas as pd
import numpy as np

warnings.filterwarnings("ignore")

CHARTS_DIR = "charts"
NUMERIC_COLS = [
    "sepal_length_cm",
    "sepal_width_cm",
    "petal_length_cm",
    "petal_width_cm",
]
LABELS = {
    "sepal_length_cm": "Sepal Length (cm)",
    "sepal_width_cm":  "Sepal Width (cm)",
    "petal_length_cm": "Petal Length (cm)",
    "petal_width_cm":  "Petal Width (cm)",
}
SPECIES_COLORS = {
    "Setosa":     "#3266ad",
    "Versicolor": "#e07b39",
    "Virginica":  "#3a9e63",
}
PALETTE = list(SPECIES_COLORS.values())

sns.set_theme(style="whitegrid", font_scale=1.05)


def _save(fig, name: str) -> str:
    os.makedirs(CHARTS_DIR, exist_ok=True)
    path = os.path.join(CHARTS_DIR, name)
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"[viz] Saved → {path}")
    return path


# ── 1. Distribution Histograms ───────────────────────────────────────────────
def plot_distributions(df: pd.DataFrame) -> str:
    fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    fig.suptitle("Feature Distributions by Species", fontsize=14, fontweight="bold", y=1.01)
    axes = axes.flatten()

    for ax, col in zip(axes, NUMERIC_COLS):
        for sp, grp in df.groupby("species"):
            ax.hist(grp[col], bins=15, alpha=0.65,
                    color=SPECIES_COLORS[sp], label=sp, edgecolor="white", linewidth=0.4)
        ax.set_xlabel(LABELS[col])
        ax.set_ylabel("Count")
        ax.set_title(LABELS[col])
        ax.legend(fontsize=8)

    fig.tight_layout()
    return _save(fig, "01_distributions.png")


# ── 2. Box Plots ─────────────────────────────────────────────────────────────
def plot_boxplots(df: pd.DataFrame) -> str:
    fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    fig.suptitle("Box Plots: Feature Range per Species", fontsize=14, fontweight="bold", y=1.01)
    axes = axes.flatten()

    for ax, col in zip(axes, NUMERIC_COLS):
        sns.boxplot(data=df, x="species", y=col, palette=PALETTE,
                    width=0.5, linewidth=1.2, fliersize=3, ax=ax)
        ax.set_xlabel("")
        ax.set_ylabel(LABELS[col])
        ax.set_title(LABELS[col])

    fig.tight_layout()
    return _save(fig, "02_boxplots.png")


# ── 3. Pair Plot ─────────────────────────────────────────────────────────────
def plot_pairplot(df: pd.DataFrame) -> str:
    g = sns.pairplot(
        df, hue="species",
        vars=NUMERIC_COLS,
        palette=SPECIES_COLORS,
        plot_kws={"alpha": 0.6, "s": 25, "edgecolor": "none"},
        diag_kind="kde",
        corner=False,
    )
    g.fig.suptitle("Scatter Plot Matrix (Pair Plot)", y=1.02, fontsize=14, fontweight="bold")
    for ax in g.axes.flatten():
        if ax:
            xl = ax.get_xlabel()
            yl = ax.get_ylabel()
            if xl in LABELS: ax.set_xlabel(LABELS[xl])
            if yl in LABELS: ax.set_ylabel(LABELS[yl])
    path = os.path.join(CHARTS_DIR, "03_pairplot.png")
    g.savefig(path, dpi=130, bbox_inches="tight")
    plt.close()
    print(f"[viz] Saved → {path}")
    return path


# ── 4. Correlation Heatmap ───────────────────────────────────────────────────
def plot_correlation_heatmap(df: pd.DataFrame) -> str:
    corr = df[NUMERIC_COLS].corr()
    short = ["Sepal L", "Sepal W", "Petal L", "Petal W"]
    corr.columns = short
    corr.index   = short

    fig, ax = plt.subplots(figsize=(7, 5.5))
    mask = np.zeros_like(corr, dtype=bool)
    mask[np.triu_indices_from(mask, k=1)] = False  # show full matrix
    sns.heatmap(
        corr, annot=True, fmt=".2f", cmap="RdYlBu_r",
        vmin=-1, vmax=1, linewidths=0.5, linecolor="white",
        square=True, ax=ax, cbar_kws={"shrink": 0.8},
    )
    ax.set_title("Pearson Correlation Matrix", fontsize=14, fontweight="bold", pad=14)
    fig.tight_layout()
    return _save(fig, "04_correlation_heatmap.png")


# ── 5. Violin Plots ──────────────────────────────────────────────────────────
def plot_violins(df: pd.DataFrame) -> str:
    fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    fig.suptitle("Violin Plots: Distribution Shape per Species", fontsize=14,
                 fontweight="bold", y=1.01)
    axes = axes.flatten()

    for ax, col in zip(axes, NUMERIC_COLS):
        sns.violinplot(data=df, x="species", y=col, palette=PALETTE,
                       inner="quartile", linewidth=1.0, ax=ax)
        ax.set_xlabel("")
        ax.set_ylabel(LABELS[col])
        ax.set_title(LABELS[col])

    fig.tight_layout()
    return _save(fig, "05_violins.png")


# ── 6. Key Scatter: Petal L vs Petal W ──────────────────────────────────────
def plot_key_scatter(df: pd.DataFrame) -> str:
    fig, ax = plt.subplots(figsize=(8, 6))

    for sp, grp in df.groupby("species"):
        ax.scatter(grp["petal_length_cm"], grp["petal_width_cm"],
                   color=SPECIES_COLORS[sp], label=sp, alpha=0.75,
                   s=55, edgecolors="white", linewidth=0.4)

    # Fit lines per species
    for sp, grp in df.groupby("species"):
        z = np.polyfit(grp["petal_length_cm"], grp["petal_width_cm"], 1)
        p = np.poly1d(z)
        x_line = np.linspace(grp["petal_length_cm"].min(), grp["petal_length_cm"].max(), 100)
        ax.plot(x_line, p(x_line), color=SPECIES_COLORS[sp], linewidth=1.5, linestyle="--", alpha=0.7)

    ax.set_xlabel("Petal Length (cm)", fontsize=12)
    ax.set_ylabel("Petal Width (cm)",  fontsize=12)
    ax.set_title("Petal Length vs Petal Width\n(strongest inter-species separator, r = 0.96)",
                 fontsize=13, fontweight="bold")
    ax.legend(title="Species", fontsize=10)
    fig.tight_layout()
    return _save(fig, "06_key_scatter_petal.png")


# ── 7. Mean Feature Comparison Bar Chart ────────────────────────────────────
def plot_mean_comparison(df: pd.DataFrame) -> str:
    means = df.groupby("species")[NUMERIC_COLS].mean()
    means.columns = [LABELS[c] for c in means.columns]

    x = np.arange(len(NUMERIC_COLS))
    width = 0.25
    fig, ax = plt.subplots(figsize=(11, 6))

    for i, (sp, row) in enumerate(means.iterrows()):
        ax.bar(x + i * width, row.values, width, label=sp,
               color=PALETTE[i], alpha=0.85, edgecolor="white", linewidth=0.5)

    ax.set_xticks(x + width)
    ax.set_xticklabels([LABELS[c] for c in NUMERIC_COLS], fontsize=10)
    ax.set_ylabel("Mean value (cm)", fontsize=11)
    ax.set_title("Mean Feature Values per Species", fontsize=14, fontweight="bold")
    ax.legend(title="Species", fontsize=10)
    ax.grid(axis="y", linewidth=0.5, alpha=0.7)
    fig.tight_layout()
    return _save(fig, "07_mean_comparison.png")


# ── Run all ──────────────────────────────────────────────────────────────────
def generate_all_charts(df: pd.DataFrame) -> list[str]:
    paths = []
    paths.append(plot_distributions(df))
    paths.append(plot_boxplots(df))
    paths.append(plot_pairplot(df))
    paths.append(plot_correlation_heatmap(df))
    paths.append(plot_violins(df))
    paths.append(plot_key_scatter(df))
    paths.append(plot_mean_comparison(df))
    print(f"\n[viz] All {len(paths)} charts generated.\n")
    return paths
