"""
statistics_summary.py
----------------------
Computes descriptive statistics, group-level summaries, correlation
matrix, and skewness/kurtosis for the Iris dataset.
"""

import pandas as pd
import numpy as np
from scipy import stats


NUMERIC_COLS = [
    "sepal_length_cm",
    "sepal_width_cm",
    "petal_length_cm",
    "petal_width_cm",
]


def overall_summary(df: pd.DataFrame) -> pd.DataFrame:
    """Return descriptive statistics for all numeric features."""
    desc = df[NUMERIC_COLS].describe().T
    desc["skewness"] = df[NUMERIC_COLS].apply(stats.skew).values
    desc["kurtosis"] = df[NUMERIC_COLS].apply(stats.kurtosis).values
    desc.index.name = "feature"
    return desc.round(4)


def species_summary(df: pd.DataFrame) -> pd.DataFrame:
    """Return mean and std per species for each feature."""
    grp = df.groupby("species")[NUMERIC_COLS]
    mean = grp.mean().add_suffix("_mean")
    std  = grp.std().add_suffix("_std")
    return pd.concat([mean, std], axis=1).round(4)


def correlation_matrix(df: pd.DataFrame) -> pd.DataFrame:
    """Return Pearson correlation matrix for numeric features."""
    return df[NUMERIC_COLS].corr().round(4)


def run_anova(df: pd.DataFrame) -> pd.DataFrame:
    """One-way ANOVA for each feature across species."""
    results = []
    for col in NUMERIC_COLS:
        groups = [g[col].values for _, g in df.groupby("species")]
        f_val, p_val = stats.f_oneway(*groups)
        results.append({"feature": col, "F_statistic": round(f_val, 4), "p_value": round(p_val, 6)})
    return pd.DataFrame(results).set_index("feature")


def print_report(df: pd.DataFrame) -> None:
    """Print a formatted statistical report to the console."""
    sep = "=" * 60
    print(f"\n{sep}")
    print("  OVERALL DESCRIPTIVE STATISTICS")
    print(sep)
    print(overall_summary(df).to_string())

    print(f"\n{sep}")
    print("  SPECIES-WISE SUMMARY (mean ± std)")
    print(sep)
    print(species_summary(df).to_string())

    print(f"\n{sep}")
    print("  PEARSON CORRELATION MATRIX")
    print(sep)
    print(correlation_matrix(df).to_string())

    print(f"\n{sep}")
    print("  ONE-WAY ANOVA (feature ~ species)")
    print(sep)
    anova = run_anova(df)
    print(anova.to_string())
    print()
