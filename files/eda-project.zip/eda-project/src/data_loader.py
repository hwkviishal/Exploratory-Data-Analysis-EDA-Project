"""
data_loader.py
--------------
Loads the Iris dataset and saves it as a CSV to the data/ folder.
"""

import os
import pandas as pd
from sklearn.datasets import load_iris


def load_and_save(output_path: str = "data/iris.csv") -> pd.DataFrame:
    """Load Iris dataset, save as CSV, and return a DataFrame."""
    iris = load_iris(as_frame=True)
    df = iris.frame.copy()
    df.columns = [
        "sepal_length_cm",
        "sepal_width_cm",
        "petal_length_cm",
        "petal_width_cm",
        "species_id",
    ]
    df["species"] = df["species_id"].map({0: "Setosa", 1: "Versicolor", 2: "Virginica"})
    df.drop(columns=["species_id"], inplace=True)

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    df.to_csv(output_path, index=False)
    print(f"[data_loader] Dataset saved → {output_path}  ({len(df)} rows)")
    return df


def load_csv(path: str = "data/iris.csv") -> pd.DataFrame:
    """Load dataset from the saved CSV."""
    return pd.read_csv(path)
