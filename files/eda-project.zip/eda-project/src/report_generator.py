"""
report_generator.py
--------------------
Builds a professional multi-page PDF report using ReportLab.
Includes: cover page, dataset overview, statistical tables,
all charts, key findings, and conclusion.
"""

import os
import io
from datetime import date

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    Image, PageBreak, HRFlowable, KeepTogether,
)
from reportlab.platypus.flowables import BalancedColumns

import pandas as pd

# ── Color palette ─────────────────────────────────────────────────────────────
BLUE       = colors.HexColor("#1a3a5c")
ACCENT     = colors.HexColor("#3266ad")
LIGHT_GRAY = colors.HexColor("#f4f4f4")
MID_GRAY   = colors.HexColor("#cccccc")
TEXT_DARK  = colors.HexColor("#1e1e1e")
WHITE      = colors.white

W, H = A4


def _styles():
    base = getSampleStyleSheet()
    s = {}
    s["cover_title"] = ParagraphStyle("cover_title", parent=base["Title"],
        fontSize=28, textColor=WHITE, alignment=TA_CENTER, spaceAfter=6, leading=34)
    s["cover_sub"] = ParagraphStyle("cover_sub", parent=base["Normal"],
        fontSize=13, textColor=colors.HexColor("#c8d8f0"), alignment=TA_CENTER, spaceAfter=4)
    s["cover_meta"] = ParagraphStyle("cover_meta", parent=base["Normal"],
        fontSize=10, textColor=colors.HexColor("#aabbd4"), alignment=TA_CENTER)
    s["h1"] = ParagraphStyle("h1", parent=base["Heading1"],
        fontSize=16, textColor=BLUE, spaceBefore=18, spaceAfter=6, leading=20,
        borderPad=4, borderColor=ACCENT, borderWidth=0)
    s["h2"] = ParagraphStyle("h2", parent=base["Heading2"],
        fontSize=12, textColor=ACCENT, spaceBefore=12, spaceAfter=4)
    s["body"] = ParagraphStyle("body", parent=base["Normal"],
        fontSize=10, textColor=TEXT_DARK, spaceAfter=6, leading=15, alignment=TA_JUSTIFY)
    s["caption"] = ParagraphStyle("caption", parent=base["Normal"],
        fontSize=8.5, textColor=colors.HexColor("#666666"), alignment=TA_CENTER,
        spaceBefore=3, spaceAfter=10, fontName="Helvetica-Oblique")
    s["finding"] = ParagraphStyle("finding", parent=base["Normal"],
        fontSize=10, textColor=TEXT_DARK, spaceAfter=5, leading=15,
        leftIndent=12, bulletIndent=0)
    s["footer"] = ParagraphStyle("footer", parent=base["Normal"],
        fontSize=8, textColor=MID_GRAY, alignment=TA_CENTER)
    return s


def _df_to_table(df: pd.DataFrame, col_widths=None) -> Table:
    """Convert a DataFrame to a styled ReportLab Table."""
    df = df.reset_index()
    header = [str(c) for c in df.columns]
    rows   = [[str(round(v, 4)) if isinstance(v, float) else str(v) for v in row]
              for row in df.itertuples(index=False)]
    data = [header] + rows

    t = Table(data, colWidths=col_widths, repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND",    (0, 0), (-1, 0),  ACCENT),
        ("TEXTCOLOR",     (0, 0), (-1, 0),  WHITE),
        ("FONTNAME",      (0, 0), (-1, 0),  "Helvetica-Bold"),
        ("FONTSIZE",      (0, 0), (-1, 0),  8.5),
        ("ALIGN",         (0, 0), (-1, -1), "CENTER"),
        ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
        ("FONTNAME",      (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE",      (0, 1), (-1, -1), 8),
        ("ROWBACKGROUNDS",(0, 1), (-1, -1), [WHITE, LIGHT_GRAY]),
        ("GRID",          (0, 0), (-1, -1), 0.4, MID_GRAY),
        ("TOPPADDING",    (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LEFTPADDING",   (0, 0), (-1, -1), 6),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 6),
    ]))
    return t


def _img(path: str, width=14*cm) -> Image:
    """Load a chart image, preserving aspect ratio."""
    img = Image(path)
    ratio = img.imageHeight / img.imageWidth
    img.drawWidth  = width
    img.drawHeight = width * ratio
    return img


def _cover_page(styles) -> list:
    """Return flowables for the cover page."""
    story = []
    # Blue header block via a Table trick
    cover_data = [[
        Paragraph("Exploratory Data Analysis", styles["cover_title"]),
    ]]
    cover_table = Table(cover_data, colWidths=[W - 4*cm])
    cover_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), BLUE),
        ("TOPPADDING",    (0, 0), (-1, -1), 60),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 60),
        ("LEFTPADDING",   (0, 0), (-1, -1), 20),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 20),
    ]))
    story.append(Spacer(1, 1.5*cm))
    story.append(cover_table)
    story.append(Spacer(1, 0.6*cm))

    meta = [
        ("Dataset", "Iris Flower Dataset (UCI ML Repository)"),
        ("Domain",  "Biological Classification / Botany"),
        ("Samples", "150  |  3 Species  |  4 Numeric Features"),
        ("Date",    str(date.today())),
        ("Prepared by", "Data Science Intern"),
        ("Tool", "Python 3 · pandas · matplotlib · seaborn · scipy"),
    ]
    for k, v in meta:
        story.append(Paragraph(f"<b>{k}:</b>  {v}", styles["cover_sub"]))
        story.append(Spacer(1, 0.15*cm))

    story.append(Spacer(1, 1*cm))
    story.append(HRFlowable(width="80%", thickness=1, color=ACCENT, spaceAfter=0.5*cm))
    story.append(Paragraph(
        "This report presents a comprehensive Exploratory Data Analysis of the classic "
        "Iris dataset, covering statistical summaries, distribution analysis, correlation "
        "structure, inter-species comparisons, and key findings relevant to classification tasks.",
        styles["body"],
    ))
    story.append(PageBreak())
    return story


def _toc(styles) -> list:
    """Simple table of contents."""
    story = [Paragraph("Table of Contents", styles["h1"]),
             HRFlowable(width="100%", thickness=0.5, color=MID_GRAY, spaceAfter=8)]
    items = [
        ("1.", "Dataset Overview"),
        ("2.", "Descriptive Statistics"),
        ("3.", "Species-wise Summary"),
        ("4.", "Correlation Analysis"),
        ("5.", "Visual Analysis"),
        ("6.", "Key Findings & Insights"),
        ("7.", "Conclusion"),
    ]
    for num, title in items:
        story.append(Paragraph(f"{num}  {title}", styles["body"]))
    story.append(PageBreak())
    return story


def generate_report(df: pd.DataFrame, chart_paths: list[str],
                    stats_module, output_path: str = "report/EDA_Report.pdf") -> str:
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    styles = _styles()

    doc = SimpleDocTemplate(
        output_path, pagesize=A4,
        leftMargin=2.2*cm, rightMargin=2.2*cm,
        topMargin=2*cm, bottomMargin=2.2*cm,
        title="EDA Report – Iris Dataset",
        author="Data Science Intern",
    )

    story = []

    # ── Cover ─────────────────────────────────────────────────────────────────
    story += _cover_page(styles)

    # ── TOC ───────────────────────────────────────────────────────────────────
    story += _toc(styles)

    # ── 1. Dataset Overview ───────────────────────────────────────────────────
    story.append(Paragraph("1. Dataset Overview", styles["h1"]))
    story.append(HRFlowable(width="100%", thickness=0.5, color=MID_GRAY, spaceAfter=6))
    story.append(Paragraph(
        "The Iris dataset was introduced by British statistician Ronald Fisher in 1936. "
        "It contains measurements of four morphological features (sepal length, sepal width, "
        "petal length, petal width) across 150 flower samples from three species of iris: "
        "<i>Iris setosa</i>, <i>Iris versicolor</i>, and <i>Iris virginica</i>. "
        "Each species is represented by exactly 50 samples, making the dataset perfectly balanced.",
        styles["body"],
    ))
    story.append(Spacer(1, 0.3*cm))

    overview_data = pd.DataFrame({
        "Property": ["Total samples", "Features", "Target classes", "Missing values",
                      "Class balance", "Feature types"],
        "Value": ["150", "4 numeric", "3 (Setosa / Versicolor / Virginica)",
                  "None", "Perfectly balanced (50 each)", "Continuous (cm)"],
    })
    story.append(_df_to_table(overview_data, col_widths=[6*cm, 10*cm]))
    story.append(Spacer(1, 0.5*cm))

    # First 5 rows sample
    story.append(Paragraph("Sample rows from the dataset:", styles["h2"]))
    sample = df.head(5).copy()
    sample.index.name = "row"
    sample = sample.reset_index(drop=True)
    story.append(_df_to_table(sample))
    story.append(PageBreak())

    # ── 2. Descriptive Statistics ─────────────────────────────────────────────
    story.append(Paragraph("2. Descriptive Statistics", styles["h1"]))
    story.append(HRFlowable(width="100%", thickness=0.5, color=MID_GRAY, spaceAfter=6))
    story.append(Paragraph(
        "The table below summarises central tendency, spread, and shape metrics for each "
        "numeric feature across all 150 observations.",
        styles["body"],
    ))
    overall = stats_module.overall_summary(df)
    story.append(_df_to_table(overall))
    story.append(Spacer(1, 0.4*cm))

    story.append(Paragraph("3. Species-wise Summary", styles["h1"]))
    story.append(HRFlowable(width="100%", thickness=0.5, color=MID_GRAY, spaceAfter=6))
    story.append(Paragraph(
        "Splitting the dataset by species reveals striking differences in mean petal "
        "dimensions, confirming that petal measurements are the most discriminative features.",
        styles["body"],
    ))
    sp_sum = stats_module.species_summary(df)
    story.append(_df_to_table(sp_sum))
    story.append(Spacer(1, 0.4*cm))

    story.append(Paragraph("One-way ANOVA (feature ~ species)", styles["h2"]))
    story.append(Paragraph(
        "All four features show statistically significant differences across species "
        "(p &lt; 0.001 for each), validating the use of these measurements for classification.",
        styles["body"],
    ))
    anova = stats_module.run_anova(df)
    story.append(_df_to_table(anova))
    story.append(PageBreak())

    # ── 4. Correlation Analysis ───────────────────────────────────────────────
    story.append(Paragraph("4. Correlation Analysis", styles["h1"]))
    story.append(HRFlowable(width="100%", thickness=0.5, color=MID_GRAY, spaceAfter=6))
    story.append(Paragraph(
        "The Pearson correlation matrix below quantifies linear relationships between "
        "pairs of features. A value near +1 indicates a strong positive relationship, "
        "near -1 a strong negative one, and near 0 indicates no linear association.",
        styles["body"],
    ))
    corr = stats_module.correlation_matrix(df)
    story.append(_df_to_table(corr))
    story.append(Spacer(1, 0.3*cm))
    story.append(Paragraph(
        "Notable finding: petal length and petal width share a Pearson r of <b>0.9629</b>, "
        "indicating near-perfect collinearity. In a machine learning context this suggests "
        "only one of the two needs to be retained when using linear models.",
        styles["body"],
    ))

    # Heatmap chart
    heatmap_path = [p for p in chart_paths if "heatmap" in p]
    if heatmap_path:
        story.append(Spacer(1, 0.4*cm))
        story.append(_img(heatmap_path[0], width=12*cm))
        story.append(Paragraph("Figure 4.1 — Pearson correlation heatmap", styles["caption"]))
    story.append(PageBreak())

    # ── 5. Visual Analysis ────────────────────────────────────────────────────
    story.append(Paragraph("5. Visual Analysis", styles["h1"]))
    story.append(HRFlowable(width="100%", thickness=0.5, color=MID_GRAY, spaceAfter=6))

    chart_meta = [
        ("distributions", "5.1", "Feature Distributions",
         "Histograms stacked by species show that petal features have clearly separated "
         "modes per species, while sepal width distributions overlap considerably."),
        ("boxplot", "5.2", "Box Plots",
         "Box plots confirm that Setosa has distinctly smaller petals. Versicolor and "
         "Virginica show overlapping interquartile ranges, especially in sepal measurements."),
        ("pairplot", "5.3", "Scatter Plot Matrix",
         "The pair plot reveals that petal-based scatter plots produce the cleanest "
         "cluster separation. Setosa is fully linearly separable; the other two overlap slightly."),
        ("violin", "5.4", "Violin Plots",
         "Violin plots expose the underlying density shape. Setosa's petal width "
         "distribution is narrow and unimodal; Virginica shows a wider spread."),
        ("key_scatter", "5.5", "Key Scatter: Petal Length vs Petal Width",
         "This is the single most informative 2D view. The dashed regression lines "
         "illustrate that each species follows a consistent growth ratio."),
        ("mean_comp", "5.6", "Mean Feature Comparison",
         "Grouped bar chart of per-species means makes the magnitude of differences "
         "immediately apparent, especially for petal dimensions."),
    ]

    for keyword, fig_num, title, caption_text in chart_meta:
        matched = [p for p in chart_paths if keyword in p]
        if not matched:
            continue
        story.append(Paragraph(f"{fig_num}. {title}", styles["h2"]))
        story.append(Paragraph(caption_text, styles["body"]))
        story.append(_img(matched[0], width=14*cm))
        story.append(Paragraph(f"Figure {fig_num} — {title}", styles["caption"]))
        story.append(Spacer(1, 0.3*cm))

    story.append(PageBreak())

    # ── 6. Key Findings ───────────────────────────────────────────────────────
    story.append(Paragraph("6. Key Findings &amp; Insights", styles["h1"]))
    story.append(HRFlowable(width="100%", thickness=0.5, color=MID_GRAY, spaceAfter=8))

    findings = [
        ("<b>Petal features dominate species separation.</b>  Petal length and petal width "
         "have the highest discriminative power. A simple threshold on petal length "
         "(&lt; 2.5 cm) isolates Setosa with 100% accuracy."),
        ("<b>Sepal width is the weakest predictor.</b>  With a correlation of only "
         "–0.12 to sepal length and near-zero F-statistic compared to petal features, "
         "sepal width adds minimal classification signal."),
        ("<b>Setosa is linearly separable.</b>  Across all scatter plots, Setosa forms "
         "a compact, well-isolated cluster. Versicolor and Virginica partially overlap, "
         "requiring a non-linear decision boundary for high-accuracy classification."),
        ("<b>High petal collinearity (r = 0.96).</b>  Petal length and petal width are "
         "almost perfectly correlated. PCA would collapse them into a single principal "
         "component with less than 4% information loss."),
        ("<b>ANOVA confirms statistical significance.</b>  One-way ANOVA yields F-statistics "
         "exceeding 1000 for petal features (p &lt; 0.001), confirming that species "
         "differences are not due to chance."),
        ("<b>Recommended models:</b>  Given the linear separability of one class and mild "
         "non-linearity between the other two, Logistic Regression, LDA, k-NN (k=3), "
         "and SVM with RBF kernel are expected to perform well (95–98% accuracy)."),
    ]

    for i, f in enumerate(findings, 1):
        story.append(Paragraph(f"• {f}", styles["finding"]))
        story.append(Spacer(1, 0.2*cm))

    story.append(PageBreak())

    # ── 7. Conclusion ─────────────────────────────────────────────────────────
    story.append(Paragraph("7. Conclusion", styles["h1"]))
    story.append(HRFlowable(width="100%", thickness=0.5, color=MID_GRAY, spaceAfter=6))
    story.append(Paragraph(
        "This Exploratory Data Analysis of the Iris dataset demonstrates the importance "
        "of combining statistical summaries with visualizations. Through histograms, "
        "box plots, pair plots, violin plots, and correlation analysis, we established "
        "that petal dimensions are the primary drivers of inter-species variation.",
        styles["body"],
    ))
    story.append(Paragraph(
        "The dataset is clean, balanced, and well-suited for supervised classification. "
        "Future work could include Principal Component Analysis (PCA) to visualise the "
        "data in 2D, clustering experiments (k-Means, DBSCAN) to validate natural groupings "
        "without labels, and benchmarking multiple classifiers to identify the optimal model "
        "for production deployment.",
        styles["body"],
    ))
    story.append(Spacer(1, 0.5*cm))
    story.append(HRFlowable(width="60%", thickness=0.5, color=MID_GRAY))
    story.append(Spacer(1, 0.3*cm))
    story.append(Paragraph(
        "Report generated with Python 3 · pandas · matplotlib · seaborn · scipy · ReportLab",
        styles["footer"],
    ))

    doc.build(story)
    print(f"\n[report] PDF saved → {output_path}")
    return output_path
